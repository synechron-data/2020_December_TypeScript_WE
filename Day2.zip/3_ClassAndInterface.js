"use strict";
var Cashier = (function () {
    function Cashier() {
    }
    Cashier.prototype.applyLoan = function () {
        console.log("Loan Applied...");
    };
    return Cashier;
}());
var BankManager = (function () {
    function BankManager() {
    }
    BankManager.prototype.approveLoan = function () {
        console.log("Loan Applied...");
    };
    return BankManager;
}());
var SpecialManager = (function () {
    function SpecialManager() {
    }
    SpecialManager.prototype.applyLoan = function () {
        throw new Error("Method not implemented.");
    };
    SpecialManager.prototype.approveLoan = function () {
        throw new Error("Method not implemented.");
    };
    return SpecialManager;
}());
