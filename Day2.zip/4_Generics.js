"use strict";
function getLength(arg) {
    return arg.length;
}
console.log(getLength("Manish"));
console.log(getLength(["Manish"]));
console.log(getLength([10, 20, 30, 40, 50]));
